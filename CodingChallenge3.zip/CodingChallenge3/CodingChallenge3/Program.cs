﻿// Things we need to do:
// 1. Open the file.
// 2. Read the passage from the file.
// 3. Count the instances of each word.
// 4. Write the results to a file.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace CodingChallenge3
{
    class Program
    {
        static void Main(string[] args)
        {
            // Read the passage.txt file and put all the data in a string.
            StreamReader sr = new StreamReader("passage.txt");
            string rawData = sr.ReadToEnd();
            sr.Close();

            rawData = rawData.ToLower();

            string temp = "";
            foreach (char c in rawData)
            {
                if (c >= 'a' && c <= 'z' || c == ' ') 
                {
                    temp += c;
                }
            }

            string[] words = temp.Split(' ');

            SortedDictionary<string, int> Dictionary = new SortedDictionary<string, int>();

            foreach (string word in words)
            {
                if (Dictionary.ContainsKey(word))
                {
                    Dictionary[word]++;
                }
                else
                {
                    Dictionary[word] = 1;
                }
            }

            StreamWriter sw = new StreamWriter("tallies.txt");
            sw.WriteLine("{0, -20}{1, 20}", "WORD", "COUNT");
            sw.WriteLine("----------------------------------------");

            foreach (KeyValuePair<string, int> kvp in Dictionary)
            {
                if (kvp.Key != "")
                {
                    sw.WriteLine("{0, -20}{1, 20}", kvp.Key, kvp.Value);
                }
            }

            sw.Close();         
        }
    }
}
